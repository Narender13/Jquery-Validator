 $(document).ready(function () {
	 $('#btn').click(function () {
        if ($("form[name='registration']").valid()) {
           alert("hgi") 
        }
    });
	   });