
$(document).ready(function () {
	
    $("form[name='registration']").validate({// initialize plugin
	  
                    //by default validation will run on input keyup and focusout
                   
      onkeypress: false,
                   
      rules: {
      // The key name on the left side is the name attribute
      // of an input field. Validation rules are defined
      // on the right side
      firstname: "required",
      lastname: "required",
      email: {
        //required: false,
		check: true,
        // Specify that email should be validated
        // by the built-in "email" rule
        email: true
      },
      password: {
        required: true,
         minlength: 5,
      }/*,
	  siteurl:{
		  required:true,
		  url:true
	  }*/
    },
    // Specify validation error messages
    messages: {
      firstname: "Please enter your firstname",
      lastname: "Please enter your lastname",
      password: {
        required: "Please provide a password",
        minlength: "Your password must be at least 5 characters long"
      },
        email: {
        required: "Please provide a email",
      },
	 // siteurl: "Please enter a valid URL"
    },

    });
	
	$.validator.addMethod("check", function(value, element) {	
      return this.optional(element) || element.value.length > 5;
      },"Minimum 5 character are required.");
	
$('input, select, radio, checkbox').keypress(function(){
$("form[name='registration']").validate().element(this);
});
});